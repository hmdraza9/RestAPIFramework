package test.pojo.classes;

public class Location {

	private float lat;
	private float lng;

	// Getter Methods

	public float getLat() {
		return lat;
	}

	public float getLng() {
		return lng;
	}

	// Setter Methods

	public void setLat(float lat) {
		this.lat = lat;
	}

	public void setLng(float lng) {
		this.lng = lng;
	}
}
