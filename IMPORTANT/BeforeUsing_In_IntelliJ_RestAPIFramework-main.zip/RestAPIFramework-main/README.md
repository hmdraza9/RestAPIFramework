# RestAPIFramework

Started with Rest API and BDD, first step working

All step working, added optimization

Added Logger, working, added property file reader and using them

Added Enum to read URIs

Completed as E2E scenario, add place, verify place

Added delete place

23 Dec 2023 - Some changes

See Cucumber reports online, set ENV variable, ref: https://reports.cucumber.io/ [ login with github ], https://stackoverflow.com/questions/7048216/environment-variables-in-eclipse, same using MAVEN from command